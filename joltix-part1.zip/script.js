var q=document.getElementById('q'),r=document.getElementById('res'),L=null;
if(q){q.addEventListener('focus',function(){if(!L)fetch('/search.json').then(function(x){return x.json()}).then(function(j){L=j})});
q.addEventListener('input',function(){var t=q.value.trim().toLowerCase();if(!t||!L){r.hidden=true;return}
var m=L.filter(function(g){return g[1].toLowerCase().indexOf(t)>-1}).slice(0,8);
r.innerHTML=m.map(function(g){return '<a href="/game/'+g[0]+'/"><img src="'+g[2]+'" alt="" width="48" height="36"><span>'+g[1].replace(/</g,'&lt;')+'</span></a>'}).join('')||'<a href="#">No games found</a>';r.hidden=false});
document.addEventListener('click',function(e){if(!e.target.closest('.sb'))r.hidden=true})}
var p=document.getElementById('play');if(p)p.addEventListener('click',function(){var f=document.createElement('iframe');f.src=p.dataset.src;f.allow=p.dataset.allow;f.setAttribute('allowfullscreen','');f.title=p.dataset.t;p.parentNode.innerHTML='';document.querySelector('.player').appendChild(f)});